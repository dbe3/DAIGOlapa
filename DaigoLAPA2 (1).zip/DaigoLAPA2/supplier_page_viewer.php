<html lang="en">
<head>

</head>
	<title>DaigoLAPA</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="css/homeStyle.css">
	<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
	
	<?php
		session_start();
		$username = $_SESSION['user_name'];
		if(!isset($username)){
			header("Location: login.php");
		}
	?>
	<body>
		
		<div class="header">
			<div class="greeting_msg">
				<a href="index_viewer.php"><font face="calibri" color="white">Welcome back, <?php echo $username ?></font></a>
			</div>
		
			
			<div class="btn-group dropleft">
				<button class="btn btn-secondary btn-lg dropdown-toggle" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
					<input type="image" class="icon" src="images/acc_icon.png" />
				</button>
					<div class="dropdown-menu">
							<a class="dropdown-item" href="account.php">Account</a>
							<a class="dropdown-item" href="help.php">Help</a>
							<a class="dropdown-item" href="about.php">About</a>
							<a class="dropdown-item" href="logout.php">Log Out</a>
					</div>
			</div>
		</div>
 <div id="Tokyo" class="tabcontent">
  <h1>DaigoLAPA</h1>
  <p>Inventory Management System</p>
</div>		
<div>
<a href="index_viewer.php"><button class="tablink" onclick="openCity('London', this, '#079e80')">DaigoLAPA</button></a>
<a href="prod_page_viewer.php"><button class="tablink" onclick="openCity('Paris', this, '#079e80')">Products</button></a>
<button class="tablink" onclick="openCity('Tokyo', this, '#079e80')" id="defaultOpen">Suppliers</button>
<button class="tablink" onclick="openCity('Oslo', this, 'orange')" disabled><font color="gray">Transactions</font></button> 
</div>

	
<div class="container">
<br><br><br>
  


  
</div>

<br>

<table class="table table-dark" id="prod_table">

	<?php
		
		$connection = mysqli_connect("localhost", "root", "");
		mysqli_select_db($connection, "daigo_db");
		
		$query = "SELECT * FROM `suppliers`";
		$result = mysqli_query($connection, $query);
	?>
	
	
    <tr>
      <th scope="col">Supplier Name</th>
	  <th scope="col">Supplier Location</th>
      <th scope="col">Supplier Contact Number</th>

    </tr>
	
		<?php
			while($rows = mysqli_fetch_assoc($result))
			{?>
				<tr>
					<td><?php echo $rows['supp_name']; ?></td>
					<td><?php echo $rows['supp_location']; ?></td>
					<td><?php echo $rows['supp_conNum']; ?></td>
									
				</tr>
				

				
			<?php
			}
			
			if(isset($_POST['update_supp'])){
            $edit_supp_id = $_POST['edit_supp_id'];
            $supp_name = $_POST['supp_name'];
			$supp_location = $_POST['supp_location'];
			$supp_conNum = $_POST['supp_conNum'];

			
            $sql = "UPDATE `suppliers` SET 			
					`supp_name`='$supp_name',
					`supp_location`='$supp_location',
					`supp_conNum`='$supp_conNum'
					WHERE supp_id='$edit_supp_id' ";
            if (mysqli_query($connection,$sql) === TRUE) {
               echo '<script>window.location.href="supplier_page.php"</script>';
               } else {
               echo "Error updating record: " . $connection->error;
              }
                }
			?>
 

</table>
		


<script type="text/javascript">
function newWarehouse(val){
 var element=document.getElementById('color');
 if(val=='pick a color'||val=='newWarehouse')
   element.style.display='block';
 else  
   element.style.display='none';
}

</script>
		
		<script>
		function openCity(cityName, elmnt, color) {

  var i, tabcontent, tablinks;
  tabcontent = document.getElementsByClassName("tabcontent");
  for (i = 0; i < tabcontent.length; i++) {
    tabcontent[i].style.display = "none";
  }

  // Remove the background color of all tablinks/buttons
  tablinks = document.getElementsByClassName("tablink");
  for (i = 0; i < tablinks.length; i++) {
    tablinks[i].style.backgroundColor = "";
  }

  // Show the specific tab content
  document.getElementById(cityName).style.display = "block";

  // Add the specific color to the button used to open the tab content
  elmnt.style.backgroundColor = color;
}

// Get the element with id="defaultOpen" and click on it
document.getElementById("defaultOpen").click(); 
	</script>
		
		

	

</body>
</html>