<?php
$username = $_POST['username'];
$prod_id = $_POST['prod_id'];
$transaction_code = "PD-".$_POST['transaction_code'];
$supp_id = $_POST['supp_id'];
$quantityToBeAdded = $_POST['quantityToBeAdded'];
$transaction_type = "Product Delivery";
$conn = mysqli_connect("localhost", "root", "");
mysqli_select_db($conn, "daigo_db");
$query = "SELECT * FROM products WHERE prod_id='$prod_id'";
$result = mysqli_query($conn, $query);
$rows = mysqli_fetch_assoc($result);
$oldQuan = $rows['prod_quantity'];
$prod_name = $rows['prod_name'];
$warehouse_id = $rows['warehouse_id'];
$newQuan = $oldQuan + $quantityToBeAdded;
$date = date("Y/m/d");
$sql = "UPDATE products SET `prod_quantity`='$newQuan' WHERE prod_id='$prod_id'";
mysqli_query($conn, $sql);

$sql = "INSERT INTO `transactions`(`transaction_code`, `transaction_type`, `encoder`, `prod_id`, `supp_id`, `warehouse_id`, `quantity`, `date`) 
		VALUES (
		'".$transaction_code."',
		'".$transaction_type."',
		'".$username."',
		'".$prod_id."',
		'".$supp_id."',
		'".$warehouse_id."',
		'".$quantityToBeAdded."',
		'".$date."')";
mysqli_query($conn, $sql);		
header("Location: prod_page.php");
?>