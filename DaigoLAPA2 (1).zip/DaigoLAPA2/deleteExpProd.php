<?php
$conn = mysqli_connect("localhost","root","");
mysqli_select_db($conn, "daigo_db");

$prod_id = $_POST['prod_id'];
$encoder = $_POST['username'];

$query = "SELECT * FROM products WHERE prod_id='$prod_id'";
$result = mysqli_query($conn, $query);
$rows = mysqli_fetch_assoc($result);
$prod_name = $rows['prod_name'];
$supp_id = $rows['supp_id'];
$warehouse_id = $rows['warehouse_id'];
$prod_quantity = $rows['prod_quantity'];
$date = date("Y/m/d");
$transaction_code = "Return ".$prod_name;
$transaction_type = "Product Removal";
$prod_status = "Removed";
$prod_expDate = null; 



$sql = "INSERT INTO `transactions`(`transaction_code`, `transaction_type`, `encoder`, `supp_id`, `warehouse_id`, `quantity`, `date`) 
		VALUES 
		('".$transaction_code."',
		'".$transaction_type."',
		'".$encoder."',
		'".$supp_id."',
		'".$warehouse_id."',
		'".$prod_quantity."',
		'".$date."')";
		
		mysqli_query($conn, $sql);

$sql = "UPDATE products SET `prod_status`='$prod_status', `prod_expDate`='$prod_expDate' WHERE prod_id='$prod_id'";
		mysqli_query($conn, $sql);
		

		header("Location: index.php");

?>