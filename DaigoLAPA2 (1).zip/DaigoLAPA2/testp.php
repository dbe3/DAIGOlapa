<?php
$conn = mysqli_connect("localhost", "root", "");
mysqli_select_db($conn, "daigo_db");

$encoder = $_POST['username'];
$transaction_code = "PD-".$_POST['transaction_code'];
$transaction_type = "Product Delivery";
$prod_code = $_POST['prod_code'];
$prod_name = $_POST['prod_name'];
$prod_price = $_POST['prod_price'];
$prod_type = $_POST['prod_type'];
$prod_quantity = $_POST['prod_quantity'];
$prod_critQuan = $_POST['prod_critQuan'];
$prod_expDate = $_POST['prod_expDate'];
$supp_id = $_POST['supp_id'];
$warehouse_id = $_POST['warehouse_id'];
$date = date("Y/m/d");

if(!isset($_POST['warehouse_name']) && !isset($_POST['supp_name'])){
	$sql = "INSERT INTO `products`(`prod_code`, `prod_name`, `prod_price`, `prod_type`, `prod_quantity`, `prod_critQuan`, `prod_expDate`, `supp_id`, `warehouse_id`) 
			VALUES 
			('".$prod_code."',
			'".$prod_name."',
			'".$prod_price."',
			'".$prod_type."',
			'".$prod_quantity."',
			'".$prod_critQuan."',
			'".$prod_expDate."',
			'".$supp_id."',
			'".$warehouse_id."')";
			mysqli_query($conn, $sql);
			
		$sql = "SELECT prod_id FROM products WHERE prod_code='$prod_code' AND warehouse_id='$warehouse_id'";
		$res = mysqli_query($conn, $sql);
		$rows = mysqli_fetch_assoc($res);
		$prod_id = $rows['prod_id'];
			
		$sql = "INSERT INTO `transactions`(`transaction_code`, `transaction_type`, `encoder`, `prod_id`, `supp_id`, `warehouse_id`, `quantity`, `date`) 
				VALUES 
				('".$transaction_code."',
				'".$transaction_type."',
				'".$encoder."',
				'".$prod_id."',
				'".$supp_id."',
				'".$warehouse_id."',
				'".$prod_quantity."',
				'".$date."')";
		mysqli_query($conn, $sql);
		header("Location: prod_page.php");
		
}else if(!isset($_POST['warehouse_name'])){
	$supp_name = $_POST['supp_name'];
	$supp_location = $_POST['supp_location'];
	$supp_conNum = $_POST['supp_conNum'];
	
	$sql = "INSERT INTO `suppliers`(`supp_name`, `supp_location`, `supp_conNum`) 
			VALUES 
			('".$supp_name."',
			'".$supp_location."',
			'".$supp_conNum."')";
	mysqli_query($conn, $sql);
	
	$sql = "SELECT supp_id FROM suppliers WHERE supp_name='$supp_name'";
	$res = mysqli_query($conn, $sql);
	$rows = mysqli_fetch_assoc($res);
	$supp_id = $rows['supp_id'];
	
	$sql = "INSERT INTO `products`(`prod_code`, `prod_name`, `prod_price`, `prod_type`, `prod_quantity`, `prod_critQuan`, `prod_expDate`, `supp_id`, `warehouse_id`) 
			VALUES 
			('".$prod_code."',
			'".$prod_name."',
			'".$prod_price."',
			'".$prod_type."',
			'".$prod_quantity."',
			'".$prod_critQuan."',
			'".$prod_expDate."',
			'".$supp_id."',
			'".$warehouse_id."')";
			mysqli_query($conn, $sql);	
			
		$sql = "SELECT prod_id FROM products WHERE prod_code='$prod_code' AND warehouse_id='$warehouse_id'";
		$res = mysqli_query($conn, $sql);
		$rows = mysqli_fetch_assoc($res);
		$prod_id = $rows['prod_id'];		
			
		$sql = "INSERT INTO `transactions`(`transaction_code`, `transaction_type`, `encoder`, `prod_id`, `supp_id`, `warehouse_id`, `quantity`, `date`) 
				VALUES 
				('".$transaction_code."',
				'".$transaction_type."',
				'".$encoder."',
				'".$prod_id."',
				'".$supp_id."',
				'".$warehouse_id."',
				'".$prod_quantity."',
				'".$date."')";
		mysqli_query($conn, $sql);
		header("Location: prod_page.php");			
	
}else if(!isset($_POST['supp_name'])){
	$warehouse_name = $_POST['warehouse_name'];
	$warehouse_location = $_POST['warehouse_location'];
	$warehouse_conNum = $_POST['warehouse_conNum'];
	
	$sql = "INSERT INTO `warehouses`(`warehouse_name`, `warehouse_location`, `warehouse_conNum`) 
			VALUES 
			('".$warehouse_name."',
			'".$warehouse_location."',
			'".$warehouse_conNum."')";
	mysqli_query($conn, $sql);
	
	$sql = "SELECT warehouse_id FROM warehouses WHERE `warehouse_name`='$warehouse_name'";
	$res = mysqli_query($conn, $sql);
	$rows = mysqli_fetch_assoc($res);
	$warehouse_id = $rows['warehouse_id'];
	
	$sql = "INSERT INTO `products`(`prod_code`, `prod_name`, `prod_price`, `prod_type`, `prod_quantity`, `prod_critQuan`, `prod_expDate`, `supp_id`, `warehouse_id`) 
			VALUES 
			('".$prod_code."',
			'".$prod_name."',
			'".$prod_price."',
			'".$prod_type."',
			'".$prod_quantity."',
			'".$prod_critQuan."',
			'".$prod_expDate."',
			'".$supp_id."',
			'".$warehouse_id."')";
			mysqli_query($conn, $sql);
			
		$sql = "SELECT prod_id FROM products WHERE prod_code='$prod_code' AND warehouse_id='$warehouse_id'";
		$res = mysqli_query($conn, $sql);
		$rows = mysqli_fetch_assoc($res);
		$prod_id = $rows['prod_id'];	

		$sql = "INSERT INTO `transactions`(`transaction_code`, `transaction_type`, `encoder`, `prod_id`, `supp_id`, `warehouse_id`, `quantity`, `date`) 
				VALUES 
				('".$transaction_code."',
				'".$transaction_type."',
				'".$encoder."',
				'".$prod_id."',
				'".$supp_id."',
				'".$warehouse_id."',
				'".$prod_quantity."',
				'".$date."')";
		mysqli_query($conn, $sql);		
			
	header("Location: prod_page.php");
		
}else{
	$warehouse_name = $_POST['warehouse_name'];
	$warehouse_location = $_POST['warehouse_location'];
	$warehouse_conNum = $_POST['warehouse_conNum'];
	
	$sql = "INSERT INTO `warehouses`(`warehouse_name`, `warehouse_location`, `warehouse_conNum`) 
			VALUES 
			('".$warehouse_name."',
			'".$warehouse_location."',
			'".$warehouse_conNum."')";
	mysqli_query($conn, $sql);	
	
	$sql = "SELECT warehouse_id FROM warehouses WHERE `warehouse_name`='$warehouse_name'";
	$res = mysqli_query($conn, $sql);
	$rows = mysqli_fetch_assoc($res);
	$warehouse_id = $rows['warehouse_id'];	
	
	$supp_name = $_POST['supp_name'];
	$supp_location = $_POST['supp_location'];
	$supp_conNum = $_POST['supp_conNum'];
	
	$sql = "INSERT INTO `suppliers`(`supp_name`, `supp_location`, `supp_conNum`) 
			VALUES 
			('".$supp_name."',
			'".$supp_location."',
			'".$supp_conNum."')";
	mysqli_query($conn, $sql);	
	
	$sql = "SELECT supp_id FROM suppliers WHERE supp_name='$supp_name'";
	$res = mysqli_query($conn, $sql);
	$rows = mysqli_fetch_assoc($res);
	$supp_id = $rows['supp_id'];	
	
	$sql = "INSERT INTO `products`(`prod_code`, `prod_name`, `prod_price`, `prod_type`, `prod_quantity`, `prod_critQuan`, `prod_expDate`, `supp_id`, `warehouse_id`) 
			VALUES 
			('".$prod_code."',
			'".$prod_name."',
			'".$prod_price."',
			'".$prod_type."',
			'".$prod_quantity."',
			'".$prod_critQuan."',
			'".$prod_expDate."',
			'".$supp_id."',
			'".$warehouse_id."')";
			mysqli_query($conn, $sql);
			
		$sql = "SELECT prod_id FROM products WHERE prod_code='$prod_code' AND warehouse_id='$warehouse_id'";
		$res = mysqli_query($conn, $sql);
		$rows = mysqli_fetch_assoc($res);
		$prod_id = $rows['prod_id'];	

		$sql = "INSERT INTO `transactions`(`transaction_code`, `transaction_type`, `encoder`, `prod_id`, `supp_id`, `warehouse_id`, `quantity`, `date`) 
				VALUES 
				('".$transaction_code."',
				'".$transaction_type."',
				'".$encoder."',
				'".$prod_id."',
				'".$supp_id."',
				'".$warehouse_id."',
				'".$prod_quantity."',
				'".$date."')";
		mysqli_query($conn, $sql);		
			
	header("Location: prod_page.php");	
}
?>