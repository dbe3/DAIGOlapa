<html lang="en">
<head>

	<style>
		.boxed {
					width: 70%;
					height: 100%;
					background-color: #1abc9c;
					text-align: left;
					margin-left: auto;
					margin-right: auto;
					padding: 15px;
					margin-bottom:30px;
					margin-top: 20px;
				}
	</style>
	
</head>
	<title>DaigoLAPA</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="css/homeStyle.css">
	<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
	<?php
		session_start();
		$username = $_SESSION['user_name'];
	?>
	<body>
		
		<div class="header">
			<div class="greeting_msg">
				<a href="index.php"><font face="calibri" color="white">Welcome back, <?php echo $username ?></font></a>
			</div>
			
		<div class="btn-group dropleft">
			<button class="btn btn-secondary btn-lg dropdown-toggle" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
				<input type="image" class="icon" src="images/acc_icon.png" />
			</button>
				<div class="dropdown-menu">
					    <a class="dropdown-item" href="#">Account</a>
						<a class="dropdown-item" href="help.php">Help</a>
						<a class="dropdown-item" href="about.php">About</a>
						<a class="dropdown-item" href="logout.php">Log Out</a>
				</div>
		</div>
		</div>
		<br>
  
 <div class="boxed" style="color: white">
 
	<center><h1>HELP</h1></center> <br>
	
	<h2 style="font-size: 20px"><i>Products Page</i></h2>
		<p> 1. View all existing products on <b>View all products.</b> Add a new product and edit details about the item. <br>
			2. View all returned products on <b>View products for return.</b> <br>
			3. Create a new Warehouse in <b>Add new warehouse.</b> <br> </p>

	<h2 style="font-size: 20px"><i>Supplier Page</i></h2>
		<p>1. If you wish to add a supplier without a product, go to <b>Add supplier.</b> <br> </p>

	<h2 style="font-size: 20px"><i>Transaction Page</i></h2>
		<p> 1. <b>Receive products from supplier.</b> Number entered will be added in product quantity on products page. <br>
		2. <b>Transfer products to different warehouse.</b> Number entered will be deducted from a warehouse and will be added selected warehouse. <br>
		3. <b>Transfer products for return to supplier.</b> Number entered will be deducted from a warehouse and product will be sent back to supplier. <br> </p>
		
	<h2 style="font-size: 20px"><i>Menu Bar</i></h2>
		<p>
		1. View and edit your account information on <b>Account.</b> <br>
		2. Additional instructions can be found on <b>Help.</b> <br>
		3. Know more about the application on <b>About.</b> <br>
	</p>
</div>
	
	
</body>
</html>