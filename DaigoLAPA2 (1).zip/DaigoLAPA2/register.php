<?php include('register_process.php'); ?>
<html>
	<head>
	<style>
			#form-register, #form-login {
			width: 300px;
			margin: auto auto; 
			<!-- border: 1px solid #cccccc; -->
			border-radius: 10px;
			margin-top: 50px; 
			padding: 20px;
		}
		#form-register {
			width: 500px;
			
		}


	</style>

	</head>
	<link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.7.1/css/bootstrap-datepicker3.css" rel="stylesheet" id="bootstrap-css">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
	<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
	<title></title>

<body>	

		<form id="form-register" method="post" action="register_process.php">
				<div class="form-row">
					<div class="form-group col-md-6">
						<label for="inputEmail4">Username</label>
						<div <?php if (isset($username_error)): ?> class="form_error" <?php endif ?> >
						<input size="" type="text" class="form-control" name="username" id="inputEmail4" placeholder="Username" value="<?php echo $username; ?>" required>
						<?php if (isset($username_error)): ?>
						<span><?php echo $username_error; ?></span>
						<?php endif ?>
						</div>
					</div>
				<div class="form-group col-md-6">
					<label for="inputPassword4">Password</label>
					<input type="password" class="form-control" name="password" id="inputPassword4" placeholder="Password" required>

				</div>
				</div>
			<div class="form-group">
				<label for="inputAddress">Retype Password</label>
				<input type="Password" class="form-control" name="password2" id="inputAddress" onfocusout="password_match()" placeholder="Password" required>
			</div>
  <div class="form-row">
    <div class="form-group col-md-6">
      <label for="inputCity">First Name</label>
      <input type="text" name="fname"  pattern="[a-zA-Z]{1,}" class="form-control" id="inputCity" placeholder="First Name" onkeyup="lettersOnly(this)" required>
	  </div>
	  <div class="form-group col-md-6">
	  <label for="inputCity">Last Name</label>
      <input type="text" name="lname" pattern="[a-zA-Z]{1,}" class="form-control" id="inputCity" placeholder="Last Name" onkeyup="lettersOnly(this)" required>
    </div>
  </div>
 			
		</div>


				        
		
		

  <div class="form-group">
    <label for="inputAddress2">Email Address</label>
    <input type="email" class="form-control" name="emailaddress" id="inputAddress2" placeholder="Email Address" required>
  </div>
  <div class="form-group">
    <label for="contact_number">Contact Number</label>
	<input type="number" class="form-control" name="contact_number" id="inputAddress2" placeholder="Contact Number" maxlength="11" onkeyup="validateinput()" required>
  </div>		
    
 
<input type="hidden" name="privellege" value="viewer">	
  <button type="submit" name="register" class="btn btn-primary">Submit</button>
</form>
<script type="text/javascript">
	var inputbox = document.getElementById("contact_number");
	if(isNaN(parseFloat(inputbox.value))){
		inputbox.className = "red";
	}else{
		inputbox.className = "green";
	}

</script>
<script>
	function lettersOnly(input){
		var regex = /[^a-z]/gi;
		input.value = input.value.replace(regex, "");
	}
</script>	




</body>
</html>