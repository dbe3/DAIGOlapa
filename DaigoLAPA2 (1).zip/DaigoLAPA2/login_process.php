<?php
	
	session_start();
	//Getting values from login PHP
	$username = $_POST['username'];
	$password = $_POST['password'];
	
	//Connect to the database
	$connection = mysqli_connect("localhost", "root", "");
	mysqli_select_db($connection, "daigo_db");
	
	//Query Database for user
	$result = mysqli_query($connection,"SELECT * FROM `users` WHERE user_name = '$username' and password = '$password'") 
		or die("Failed to query Database ".mysqli_error());
		
	$row = mysqli_fetch_array($result);
	if($row['user_name'] == $username && $row['password'] == $password && $row['privillege'] == "admin"){
		$_SESSION['user_name'] = $username;
		header("Location: index.php");
		die();
	} else if($row['user_name'] == $username && $row['password'] == $password && $row['privillege'] == "viewer"){
		$_SESSION['user_name'] = $username;
		header("Location: index_viewer.php");
		die();
	}else{
		echo "Failed to Login";
	}
	
?>