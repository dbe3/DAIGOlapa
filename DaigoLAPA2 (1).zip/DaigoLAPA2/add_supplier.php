<?php


$supp_name = $_POST['supp_name'];
$supp_location = $_POST['supp_location'];
$supp_conNum = $_POST['supp_conNum'];




session_start();
$connection = mysqli_connect("localhost", "root", "");
mysqli_select_db($connection, "daigo_db");


	
	
	$sql = "INSERT INTO `suppliers`(`supp_name`, `supp_location`, `supp_conNum`) 
			VALUES ('".$supp_name."','".$supp_location."','".$supp_conNum."')";	
			mysqli_query($connection,$sql);
			
			header("Location: supplier_page.php");
	




?>