<?php
$conn = mysqli_connect("localhost", "root", "");
mysqli_select_db($conn, "daigo_db");

$user_id = $_POST['user_id'];
$admin = "admin";

$query = "UPDATE `users` SET `privillege`='$admin' WHERE user_id='$user_id'";
mysqli_query($conn,$query);
header("Location: account.php");
?>