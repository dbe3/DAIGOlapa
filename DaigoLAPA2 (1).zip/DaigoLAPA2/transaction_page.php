<html lang="en">
<head>
<style>
#reasonTextBox
{
    height:200px;
    font-size:12pt;
}
</style>
</head>
	<title>DaigoLAPA</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="css/homeStyle.css">
	<link rel="stylesheet" href="css/style.css">
	<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
	
	<?php
		session_start();
		$username = $_SESSION['user_name'];
		if(!isset($username)){
			header("Location: login.php");
		}
	?>
	<body>
		
		<div class="header">
			<div class="greeting_msg">
				<a href="index.php"><font face="calibri" color="white">Welcome back, <?php echo $username ?></font></a>
			</div>
		
			
			<div class="btn-group dropleft">
				<button class="btn btn-secondary btn-lg dropdown-toggle" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
					<input type="image" class="icon" src="images/acc_icon.png" />
				</button>
					<div class="dropdown-menu">
							<a class="dropdown-item" href="account.php">Account</a>
							<a class="dropdown-item" href="help.php">Help</a>
							<a class="dropdown-item" href="about.php">About</a>
							<a class="dropdown-item" href="logout.php">Log Out</a>
					</div>
			</div>
		</div>
		
 <div id="Oslo" class="tabcontent">
  <h1>DaigoLAPA</h1>
  <p>Inventory Management System</p>
</div>
<a href="index.php"><button class="tablink" onclick="openCity('London', this, '#079e80')">DaigoLAPA</button></a>
<a href="prod_page.php"><button class="tablink" onclick="openCity('Paris', this, 'green')">Products</button></a>
<a href="supplier_page.php"><button class="tablink" onclick="openCity('Tokyo', this, 'blue')">Suppliers</button></a>
<button class="tablink" onclick="openCity('Oslo', this, '#079e80')" id="defaultOpen">Transactions</button>
			
<br><br><br>	
<center>		
<button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#receiveFromSupplier">Receive Products From SUPPLIER</button><br><br>
<button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#transferToWarehouse">Transfer Products to Different Warehouse</button><br><br>
<button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#returnToWarehouse">Return Product to Supplier</button><br><br>
<button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#viewTransactionHistory">View Transaction History</button>
</center>

<div id="receiveFromSupplier" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
	  <h4 class="modal-title">Choose Process</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>
      <div class="modal-body">
        <center><button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#addNewProd">Add New Product</button></center><br>
		<center><button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#addProdQuan">Add Quantity To An Existing Product</button></center>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
		
<div id="addNewProd" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
	  <h4 class="modal-title">Add New Product</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>
      <div class="modal-body">
		<form  action="testp.php" method="post">
		<input type="hidden" name="username" value="<?php echo $username; ?>">	
		<label>Delivery Code</label>
		<input class="form-control" name="transaction_code" placeholder="Delivery Code" required><br>		
		<label>Product Code</label>
		<input class="form-control" name="prod_code" placeholder="Product Code" required><br>
		<label>Product Name</label>
		<input class="form-control" name="prod_name" placeholder="Product Name" required><br>	
		<label>Product Price</label>
		<input type="number" class="form-control" name="prod_price" placeholder="Product Price" required><br>
		<label>Product Type</label>
		<select class="form-control" name="prod_type" onchange="showfield(this.options[this.selectedIndex].value)">
			<option disabled selected value>Select a Product Type</option>
			<?php
			$conn = mysqli_connect("localhost", "root", "");
			mysqli_select_db($conn,"daigo_db");
			$query = "SELECT DISTINCT prod_type FROM `products`";
			$res = mysqli_query($conn,$query);
			while($rows = mysqli_fetch_assoc($res)){
			$prod_type = $rows['prod_type'];
			?>
			<option value="<?php echo $prod_type; ?>"><?php echo $prod_type; ?></option>
			<?php
			}
			?>
			<option value="Other">New Product Type</option> 
		</select>
		<div id="div1"></div><br>			
		<label>Product Quantity</label>
		<input type="number" class="form-control" name="prod_quantity" placeholder="Product Quantity" required><br>
		<label>Product Critical Quantity</label>
		<input type="number" class="form-control" name="prod_critQuan" placeholder="Product Critical Quantity" required><br>
		<label>Expiration Date</label><br>
		<font size="2">Leave Empty if not applicable</font>
		<input type="date" class="form-control" name="prod_expDate" placeholder="Expiration Date"><br>
		<label>Supplier</label>
		<select class="form-control" name="supp_id" onchange="showNew(this.options[this.selectedIndex].value)">
			<option disabled selected value>Select a Supplier</option>
			<?php
			$conn = mysqli_connect("localhost", "root", "");
			mysqli_select_db($conn,"daigo_db");
			$query = "SELECT * FROM `suppliers`";
			$res = mysqli_query($conn,$query);
			while($rows = mysqli_fetch_assoc($res)){
			$supp_id = $rows['supp_id'];
			$supp_name = $rows['supp_name'];
			?>
			<option value="<?php echo $supp_id; ?>"><?php echo $supp_name; ?></option>
			<?php
			}
			?>
			<option value="otherSupp">New Supplier</option> 
		</select><br>
		<div id="newSupp"></div>				
		<br>
		<label>Warehouse</label>
		<select class="form-control" name="warehouse_id" onchange="showNewWarehouse(this.options[this.selectedIndex].value)">
			<option disabled selected value>Select a Warehouse</option>
			<?php
			$conn = mysqli_connect("localhost", "root", "");
			mysqli_select_db($conn,"daigo_db");
			$que = "SELECT * FROM `warehouses`";
			$result = mysqli_query($conn,$que);
			while($rows = mysqli_fetch_assoc($result)){
			$warehouse_id = $rows['warehouse_id'];
			$warehouse_name = $rows['warehouse_name'];
			?>
			<option value="<?php echo $warehouse_id; ?>"><?php echo $warehouse_name; ?></option>
			<?php
			}
			?>
			<option value="newWarehouse">New Warehouse</option>
		</select>	
		<div id="newWarehouse1"></div><br>		
		<button type="submit" class="btn btn-info">Submit</button>
		
		</form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>


<div id="addProdQuan" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
	  <h4 class="modal-title">Add Quantity to an Existing Product</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>      
      </div>
      <div class="modal-body">
        <form action="addProdQuan.php" method="post">
		<input type="hidden" name="username" value="<?php echo $username; ?>">	
		<label>Delivery Code</label>
		<input class="form-control" name="transaction_code" placeholder="Delivery Code" required><br>
		<label>Select Product</label>
		<select class="form-control" name="prod_id">
		<option disabled selected value>Select a Product</option>
		<?php
		$query = "SELECT *,warehouses.warehouse_id FROM products INNER JOIN warehouses ON products.warehouse_id=warehouses.warehouse_id";
		$result = mysqli_query($conn,$query);
		while($rows = mysqli_fetch_assoc($result)){
			if($rows['prod_status'] == null){
		?>
		<option value="<?php echo $rows['prod_id']; ?>"><?php echo $rows['prod_name']; ?>(<?php echo $rows['warehouse_name']; ?>)</option>
		<?php
			}
		}
		?>
		</select><br>
		<label>Supplier</label>
		<select class="form-control" name="supp_id">
		<option disabled selected value>Select a Supplier</option>
		<?php
		$query = "SELECT * FROM suppliers";
		$result = mysqli_query($conn, $query);
		while($rows = mysqli_fetch_assoc($result)){
		?>
		<option value="<?php echo $rows['supp_id']; ?>"><?php echo $rows['supp_name']; ?></option>
		<?php
		}
		?>
		</select><br>
		<label>Quantity Delivered</label>
		<input type="number" class="form-control" name="quantityToBeAdded" placeholder="Quantity Delivered" required><br>		
		<button type="submit" class="btn btn-info">Submit</button>		
		</form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>	

<div id="transferToWarehouse" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
	  <h4 class="modal-title">Transfer Products To Different Warehouse</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>
      <div class="modal-body">
		<form action="transferToDifferentWarehouse.php" method="post">
		<input type="hidden" name="username" value="<?php echo $username; ?>">	
		<label>Transfer Code</label>
		<input class="form-control" name="transaction_code" placeholder="Transfer Code" required><br>		
		<label>Select A Product</label>
			<select class="form-control" name="prod_id">
			<option disabled selected value>Select a Product</option>
			<?php
			$query = "SELECT *,warehouses.warehouse_id FROM products INNER JOIN warehouses ON products.warehouse_id=warehouses.warehouse_id";
			$result = mysqli_query($conn, $query);
			while($rows = mysqli_fetch_assoc($result)){
				if($rows['prod_status'] == null){
			?>
			<option value="<?php echo $rows['prod_id']; ?>"><?php echo $rows['prod_name'];?>(<?php echo $rows['warehouse_name']; ?>)</option>
			<?php
				}
			}
			?>
			</select><br>
		<label>Select A Supplier</label>
			<select class="form-control" name="supp_id">
			<option disabled selected value>Select a Supplier</option>
			<?php
			$query = "SELECT * FROM suppliers";
			$result = mysqli_query($conn, $query);
			while($rows = mysqli_fetch_assoc($result)){
			?>
			<option value="<?php echo $rows['supp_id']; ?>"><?php echo $rows['supp_name'];?></option>
			<?php
			}
			?>
			</select><br>			
			<label>Quantity to Transfer</label>
			<input min="0" type="number" class="form-control" name="transferQuantity" placeholder="Quantity to Transfer" required><br>
			<label>Select Warehouse</label>
			<select class="form-control" name="warehouse_id">
			<option disabled selected value>Select Warehouse</option>
			<?php
			$query = "SELECT * FROM warehouses";
			$result = mysqli_query($conn, $query);
			while($rows = mysqli_fetch_assoc($result)){
			?>
			<option value="<?php echo $rows['warehouse_id']; ?>"><?php echo $rows['warehouse_name']; ?></option>
			<?php
			}
				?>
			</select><br>
			<button type="submit" class="btn btn-info">Submit</button>		
		</form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>

<div id="returnToWarehouse" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
	  <h4 class="modal-title">Return to Supplier</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>      
      </div>
      <div class="modal-body">
	  <form action="returnToSupp.php" method="post">
		<input type="hidden" name="username" value="<?php echo $username; ?>">	
		<label>Return Code</label>
		<input class="form-control" name="transaction_code" placeholder="Transfer Code" required><br>		  
		<label>Select Product</label>
			<select class="form-control" name="prod_id">
			<option disabled selected value>Select a Product</option>
			<?php
			$query = "SELECT *,warehouses.warehouse_id FROM products INNER JOIN warehouses ON products.warehouse_id=warehouses.warehouse_id";
			$result = mysqli_query($conn, $query);
			while($rows = mysqli_fetch_assoc($result)){
				if($rows['prod_status'] == null){
			?>
			<option value="<?php echo $rows['prod_id']; ?>"><?php echo $rows['prod_name'];?>&nbsp;(<?php echo $rows['warehouse_name']; ?>)</option>
			<?php
				}
			}
			?>		
			</select><br>
			<label>Quantity to Return</label>
			<input min="0" type="number" class="form-control" name="returnQuantity" placeholder="Quantity to Return" required><br>
			<label>Reason for Return  (Maxlength: 100)</label>
			 <textarea name="reason" maxlength="100" rows="2" cols="47" required>
			Enter Reason Here
			</textarea><br><br>
			<button type="submit" class="btn btn-info">Submit</button>	
			</form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>
<div id="viewTransactionHistory" class="modal fade" role="dialog">
  <div class="modal-dialog modal-lg">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title">Transaction History</h4>	  
        <button type="button" class="close" data-dismiss="modal">&times;</button>

      </div>
      <div class="modal-body">
        <table class="table table-dark" id="prod_table">
		<tr>
			<th scope="col"><center>Transaction Code</center></th>
			<th scope="col"><center>Transaction Type</center></th>
			<th scope="col"><center>Encoder</center></th>
			<th scope="col"><center>Product Name</center></th>
			<th scope="col"><center>Quantity</center></th>
			<th scope="col"><center>Supplier Name</center></th>
			<th scope="col"><center>Warehouse Name</center></th>
			<th scope="col"><center>Date</center></th>
		</tr>
		<?php
			$conn = mysqli_connect("localhost", "root", "");
			mysqli_select_db($conn, "daigo_db");
			$query = "SELECT *, suppliers.supp_id, products.prod_id, warehouses.warehouse_id FROM transactions INNER JOIN suppliers ON transactions.supp_id = suppliers.supp_id INNER JOIN warehouses on transactions.warehouse_id=warehouses.warehouse_id INNER JOIN products ON transactions.prod_id=products.prod_id";
			$result = mysqli_query($conn, $query);
			while($rows = mysqli_fetch_assoc($result)){	
		?>
		<tr>
			<td><center><?php echo $rows['transaction_code']; ?></center></td>
			<td><center><?php echo $rows['transaction_type']; ?></center></td>
			<td><center><?php echo $rows['encoder']; ?></center></td>
			<td><center><?php echo $rows['prod_name']; ?></center></td>
			<td><center><?php echo $rows['quantity']; ?></center></td>
			<td><center><?php echo $rows['supp_name']; ?></center></td>
			<td><center><?php echo $rows['warehouse_name']; ?></center></td>
			<td><center><?php echo $rows['date']; ?></center></td>
		</tr>
		<?php
			}
		?>
		</table>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>
<script type="text/javascript">
function showNew(name){
  if(name=='otherSupp')document.getElementById('newSupp').innerHTML=
  '<br><input type="text" class="form-control" name="supp_name" id="inputPassword4" placeholder="Supplier Name" required></input><input type="text" class="form-control" name="supp_location" id="inputPassword4" placeholder="Supplier Location" required></input><input type="text" class="form-control" name="supp_conNum" id="inputPassword4" placeholder="Supplier Contact Number" required></input>';
  else document.getElementById('newSupp').innerHTML='';
}
</script>

<script type="text/javascript">
function showNewWarehouse(name){
  if(name=='newWarehouse')document.getElementById('newWarehouse1').innerHTML=
  '<br><input type="text" class="form-control" name="warehouse_name" id="inputPassword4" placeholder="Warehouse Name" required></input><input type="text" class="form-control" name="warehouse_location" id="inputPassword4" placeholder="Warehouse Location" required></input><input type="number" class="form-control" name="warehouse_conNum" id="inputPassword4" placeholder="Warehouse Contact Number" required></input>';
  else document.getElementById('newWarehouse1').innerHTML='';
}
</script>

<script type="text/javascript">
function showfield(name){
  if(name=='Other')document.getElementById('div1').innerHTML=
  '<input type="text" class="form-control" name="prod_type" id="inputPassword4" placeholder="Product Type" required></input>';
  else document.getElementById('div1').innerHTML='';
}
</script>	

		<script>
		function openCity(cityName, elmnt, color) {

  var i, tabcontent, tablinks;
  tabcontent = document.getElementsByClassName("tabcontent");
  for (i = 0; i < tabcontent.length; i++) {
    tabcontent[i].style.display = "none";
  }

  // Remove the background color of all tablinks/buttons
  tablinks = document.getElementsByClassName("tablink");
  for (i = 0; i < tablinks.length; i++) {
    tablinks[i].style.backgroundColor = "";
  }

  // Show the specific tab content
  document.getElementById(cityName).style.display = "block";

  // Add the specific color to the button used to open the tab content
  elmnt.style.backgroundColor = color;
}

// Get the element with id="defaultOpen" and click on it
document.getElementById("defaultOpen").click(); 
	</script>
	
</body>
</html>