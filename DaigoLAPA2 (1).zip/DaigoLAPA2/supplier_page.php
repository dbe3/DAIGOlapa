<html lang="en">
<head>

</head>
	<title>DaigoLAPA</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="css/homeStyle.css">
	<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
	
	<?php
		session_start();
		$username = $_SESSION['user_name'];
		if(!isset($username)){
			header("Location: login.php");
		}
	?>
	<body>
		
		<div class="header">
			<div class="greeting_msg">
				<a href="index.php"><font face="calibri" color="white">Welcome back, <?php echo $username ?></font></a>
			</div>
		
			
			<div class="btn-group dropleft">
				<button class="btn btn-secondary btn-lg dropdown-toggle" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
					<input type="image" class="icon" src="images/acc_icon.png" />
				</button>
					<div class="dropdown-menu">
							<a class="dropdown-item" href="account.php">Account</a>
							<a class="dropdown-item" href="help.php">Help</a>
							<a class="dropdown-item" href="about.php">About</a>
							<a class="dropdown-item" href="logout.php">Log Out</a>
					</div>
			</div>
		</div>
 <div id="Tokyo" class="tabcontent">
  <h1>DaigoLAPA</h1>
  <p>Inventory Management System</p>
</div>		
<div>
<a href="index.php"><button class="tablink" onclick="openCity('London', this, '#079e80')">DaigoLAPA</button></a>
<a href="prod_page.php"><button class="tablink" onclick="openCity('Paris', this, '#079e80')">Products</button></a>
<button class="tablink" onclick="openCity('Tokyo', this, '#079e80')" id="defaultOpen">Suppliers</button>
<a href="transaction_page.php"><button class="tablink" onclick="openCity('Oslo', this, 'orange')">Transactions</button></a> 
</div>

	
<div class="container">
<br><br><br>
  
  <!-- Trigger the modal with a button -->
  <button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#addProd">Add Supplier</button>

  <!-- Modal -->
  <div class="modal fade" id="addProd" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title" id="myModalLabel">Supplier Information</h4>
		<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
      </div>
	  
      <div class="modal-body">
		<form action="add_supplier.php" method="post">
			<div class="form-group">
				<label>Supplier Name</label>
				<input type="text" class="form-control" name="supp_name" placeholder="Supplier Name" required>
			</div>
			
			<div class="form-group">
				<label>Supplier Location</label>
				<input type="text" class="form-control"name="supp_location" id="exampleInputPassword1" placeholder="Supplier Location" required>
			</div>
			
			
			<div class="form-group">
				<label>Supplier Contact Number</label>
				<input type="number" class="form-control" name="supp_conNum" id="exampleInputPassword1" placeholder="Supplier Contact Number" required>
			</div>			
			
			<button type="submit" class="btn btn-primary">Submit</button>
		</form>
      </div>
	
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
		
		
        
		
      </div>
      </div>
      
    </div>
  </div>
  
</div>

<br>

<table class="table table-dark" id="prod_table">

	<?php
		
		$connection = mysqli_connect("localhost", "root", "");
		mysqli_select_db($connection, "daigo_db");
		
		$query = "SELECT * FROM `suppliers`";
		$result = mysqli_query($connection, $query);
	?>
	
	
    <tr>
      <th scope="col">Supplier Name</th>
	  <th scope="col">Supplier Location</th>
      <th scope="col">Supplier Contact Number</th>
	  <th scope="col">Option</th>
    </tr>
	
		<?php
			while($rows = mysqli_fetch_assoc($result))
			{?>
				<tr>
					<td><?php echo $rows['supp_name']; ?></td>
					<td><?php echo $rows['supp_location']; ?></td>
					<td><?php echo $rows['supp_conNum']; ?></td>
					<td>
					<a href="#edit<?php echo $rows['supp_id']; ?>" data-toggle="modal">
					<button type="button" class="btn btn-success">Edit</button>
					</a>
					</td>
					
<div id="edit<?php echo $rows['supp_id']; ?>" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
	  <h4 class="modal-title">Edit Supplier</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>
      <div class="modal-body">
        <form method="post" class="form-horizontal" role="form">
		<input type="hidden" name="edit_supp_id" value="<?php echo $rows['supp_id']; ?>">
			<div class="form-group">
				<label for="prod_name">Supplier Name</label>
				<input type="text" class="form-control" name="supp_name" id="supp_name" placeholder="Supplier Name" value="<?php echo $rows['supp_name']; ?>" required>
			</div><br>
			<div class="form-group">
				<label for="prod_name">Supplier Location</label>
				<input type="text" class="form-control" name="supp_location" id="supp_location" placeholder="Supplier Location" value="<?php echo $rows['supp_location']; ?>" required>
			</div><br>	
			<div class="form-group">
				<label for="prod_name">Supplier Contact Number</label>
				<input type="text" class="form-control" name="supp_conNum" id="supp_conNum" placeholder="Supplier Contact Number" value="<?php echo $rows['supp_conNum']; ?>" required>
			</div><br>		
			<button type="submit" name="update_supp" class="btn btn-info">Edit</button>	
		</form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>					
				</tr>
				

				
			<?php
			}
			
			if(isset($_POST['update_supp'])){
            $edit_supp_id = $_POST['edit_supp_id'];
            $supp_name = $_POST['supp_name'];
			$supp_location = $_POST['supp_location'];
			$supp_conNum = $_POST['supp_conNum'];

			
            $sql = "UPDATE `suppliers` SET 			
					`supp_name`='$supp_name',
					`supp_location`='$supp_location',
					`supp_conNum`='$supp_conNum'
					WHERE supp_id='$edit_supp_id' ";
            if (mysqli_query($connection,$sql) === TRUE) {
               echo '<script>window.location.href="supplier_page.php"</script>';
               } else {
               echo "Error updating record: " . $connection->error;
              }
                }
			?>
 

</table>
		


<script type="text/javascript">
function newWarehouse(val){
 var element=document.getElementById('color');
 if(val=='pick a color'||val=='newWarehouse')
   element.style.display='block';
 else  
   element.style.display='none';
}

</script>
		
		<script>
		function openCity(cityName, elmnt, color) {

  var i, tabcontent, tablinks;
  tabcontent = document.getElementsByClassName("tabcontent");
  for (i = 0; i < tabcontent.length; i++) {
    tabcontent[i].style.display = "none";
  }

  // Remove the background color of all tablinks/buttons
  tablinks = document.getElementsByClassName("tablink");
  for (i = 0; i < tablinks.length; i++) {
    tablinks[i].style.backgroundColor = "";
  }

  // Show the specific tab content
  document.getElementById(cityName).style.display = "block";

  // Add the specific color to the button used to open the tab content
  elmnt.style.backgroundColor = color;
}

// Get the element with id="defaultOpen" and click on it
document.getElementById("defaultOpen").click(); 
	</script>
		
		

	

</body>
</html>