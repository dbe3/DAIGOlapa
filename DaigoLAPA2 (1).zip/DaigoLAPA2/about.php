<html lang="en">
<head>

	<style>
		.boxed {
					width: 70%;
					height: 100%;
					background-color: #1abc9c;
					text-align: left;
					margin-left: auto;
					margin-right: auto;
					padding: 15px;
					margin-bottom:30px;
					margin-top: 20px;
				}
	</style>
	
</head>
	<title>DaigoLAPA</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="css/homeStyle.css">
	<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
	<?php
		session_start();
		$username = $_SESSION['user_name'];
	?>
	<body>
		
		<div class="header">
			<div class="greeting_msg">
				<a href="index.php"><font face="calibri" color="white">Welcome back, <?php echo $username ?></font></a>
			</div>
			
		<div class="btn-group dropleft">
			<button class="btn btn-secondary btn-lg dropdown-toggle" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
				<input type="image" class="icon" src="images/acc_icon.png" />
			</button>
				<div class="dropdown-menu">
					    <a class="dropdown-item" href="account.php">Account</a>
						<a class="dropdown-item" href="help.php">Help</a>
						<a class="dropdown-item" href="about.php">About</a>
						<a class="dropdown-item" href="logout.php">Log Out</a>
				</div>
		</div>
		</div>
		<br>
		<!-- <div class="card text-center" >
	
  <div class="card-header" >
    <ul class="nav nav-tabs card-header-tabs">
      <li class="nav-item">
        <a class="nav-link active" href="#" style="color: #1abc9c">Help</a>
      </li>
    </ul>	
  </div> -->
  
 <div class="boxed" style="color: white">
 
	<center><h1>ABOUT</h1></center>
	<br>
	<h3 style="font-size: 20px"><i>PURPOSE</i></h3>
	  <br>
	  The purpose of this Project Plan is to define the software “DaigoLAPA” and the team’s end goals for this software. 
	  This project plan will contain the processes and guides needed by the team to ensure a smooth development of the application. 
	  Furthermore, this project plan will also contain guides such as Change Management Plans for potential stake holders in order to 
	  ensure proper communication with the team and the stakeholder and prevent unregulated processes.
		<br>
		<br>
	  The team’s main purpose is to provide a quick and alternative solution to a problem faced by businesses. 
	  By identifying a problem, the team narrows down ideas. By doing so, 
	  it will help the team identify what specific software they want to create.
		<br>
		<br>
	<h3 style="font-size: 20px"><i>BUSINESS AND OBJECTIVE</i></h3>
	   <br>
	   The business goals and objectives of this system includes providing a virtual Inventory Management System, 
	   minimizing time and man power needed for Inventory Management, monitoring inventories without actually being in a storage area,
	   and warning users of products that are in a “critical state”.
	   <br>
	   <br>
	 <h3 style="font-size: 20px"><i>PROJECT GOAL AND OBJECTIVE</i></h3>
	   <br>
	   The Project goals and objectives of this system are to provide an alternative process of Inventory Management, 
	   create a user-friendly software, create a well-flowing communication between the Project Team and stake holders, 
	   and help warehouse-based businesses in monitoring and managing the continuous in and out of products and materials.
</div>
					<!-- <ul class="nav navbar-nav navbar-right">

					</ul>

				</div>
					<script> 
						$('.nav nav-tabs card-header-tabs').on('click','li',function(){
						$('.nav nav-tabs card-header-tabs li-active').removeClass('active')
						});
					</script>	
			</nav>
		</div>	-->
	
	
</body>
</html>