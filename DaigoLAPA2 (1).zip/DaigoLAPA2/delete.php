<?php
$prod_id = $_POST['prod_id'];
			$connection = mysqli_connect("localhost", "root", "");
			mysqli_select_db($connection, "daigo_db");
			
			$query = "SELECT * FROM products WHERE prod_id='$prod_id'";
			$result = mysqli_query($connection, $query);
			$rows = mysqli_fetch_assoc($result);
			$prod_code = $rows['prod_code'];
			$prod_name = $rows['prod_name'];
			$transaction_code = "Return". $prod_id;
			$transaction_type = "Product Return";
			$encoder = $_POST['username'];
			$warehouse_id = $rows['warehouse_id'];
			$supp_id = $rows['supp_id'];
			$quantity = $_POST['prod_quantity'];
			$date = date("Y/m/d");
			
		$sql = "INSERT INTO `transactions`(`transaction_code`, `transaction_type`, `encoder`, `prod_id`, `supp_id`, `warehouse_id`, `quantity`, `date`) 
				VALUES 
				('".$transaction_code."',
				'".$transaction_type."',
				'".$encoder."',
				'".$prod_id."',
				'".$supp_id."',
				'".$warehouse_id."',
				'".$prod_quantity."',
				'".$date."')";
		mysqli_query($conn, $sql);
		
		
			
			$sql = "DELETE FROM `products` WHERE prod_id='$prod_id'";
			mysqli_query($connection,$sql);
			header("Location: prod_page.php");
?>