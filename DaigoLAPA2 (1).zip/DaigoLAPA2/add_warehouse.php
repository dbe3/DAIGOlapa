<?php
session_start();
$connection = mysqli_connect("localhost", "root", "");
mysqli_select_db($connection, "daigo_db");
$warehouse_name = $_POST['warehouse_name'];
$warehouse_location = $_POST['warehouse_location'];
$warehouse_conNum = $_POST['warehouse_conNum'];
$checkWarehouseName = "SELECT * FROM warehouses WHERE warehouse_name='$warehouse_name'";
$res_checkWarehouseName = mysqli_query($connection, $checkWarehouseName);

if(mysqli_num_rows($res_checkWarehouseName) > 0){
	header("Location: prod_page.php");	
}else{
	
	
	$sql = "INSERT INTO `warehouses`(`warehouse_name`, `warehouse_location`, `warehouse_conNum`) 
			VALUES ('".$warehouse_name."','".$warehouse_location."','".$warehouse_conNum."')";	
			mysqli_query($connection,$sql);
			
			header("Location: prod_page.php");
}	




?>