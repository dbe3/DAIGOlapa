<?php
$conn = mysqli_connect("localhost", "root", "");
mysqli_select_db($conn, "daigo_db");
$prod_id = $_POST['prod_id'];
$supp_id = $_POST['supp_id'];
$transferQuantity = $_POST['transferQuantity'];
$warehouse_id = $_POST['warehouse_id'];


$query = "SELECT * FROM products WHERE prod_id='$prod_id'";
$result = mysqli_query($conn, $query);
$rows = mysqli_fetch_assoc($result);
$oldQuan = $rows['prod_quantity'];
$newQuan = $oldQuan - $transferQuantity;

if($transferQuantity > $oldQuan){
	header("Location: transaction_page.php");
}else{
	if($newQuan == 0){
		$sql = "UPDATE products SET `warehouse_id`='$warehouse_id' WHERE prod_id='$prod_id'";
		mysqli_query($conn, $sql);
		
		$transaction_code = "PT-".$_POST['transaction_code'];
		$transaction_type = "Product Transfer";
		$encoder = $_POST['username'];
		$date = date("Y/m/d");
		$sql = "INSERT INTO `transactions`(`transaction_code`, `transaction_type`, `encoder`, `supp_id`, `warehouse_id`, `quantity`, `date`) 
				VALUES 
				('".$transaction_code."',
				'".$transaction_type."',
				'".$encoder."',
				'".$supp_id."',
				'".$warehouse_id."',
				'".$transferQuantity."',
				'".$date."')";
		mysqli_query($conn, $sql);
		header("Location: prod_page.php");
		
		
	}else{
		$sql = "UPDATE products SET `prod_quantity`='$newQuan' WHERE prod_id='$prod_id'";
		mysqli_query($conn, $sql);
		
		$query = "SELECT * FROM products WHERE prod_id='$prod_id'";
		$result = mysqli_query($conn, $query);
		$rows = mysqli_fetch_assoc($result);
		$prod_code = $rows['prod_code'];
		$prod_name = $rows['prod_name'];
		$prod_price = $rows['prod_price'];
		$prod_type = $rows['prod_type'];
		$prod_critQuan = $rows['prod_critQuan'];
		$prod_expDate = $rows['prod_expDate'];

		$sql = "INSERT INTO `products`(`prod_code`, `prod_name`, `prod_price`, `prod_type`, `prod_quantity`, `prod_critQuan`, `prod_expDate`, `supp_id`, `warehouse_id`) 
				VALUES 
				('".$prod_code."',
				'".$prod_name."',
				'".$prod_price."',
				'".$prod_type."',
				'".$transferQuantity."',
				'".$prod_critQuan."',
				'".$prod_expDate."',
				'".$supp_id."',
				'".$warehouse_id."')";
		mysqli_query($conn, $sql);
		
		$sql = "SELECT prod_id FROM products WHERE prod_name='$prod_name' AND warehouse_id='$warehouse_id'";
		$res = mysqli_query($conn, $sql);
		$rows = mysqli_fetch_assoc($res);
		$prod_id = $rows['prod_id'];
		$transaction_code = "PT-".$_POST['transaction_code'];
		$transaction_type = "Product Transfer";
		$encoder = $_POST['username'];
		$date = date("Y/m/d");
		$sql = "INSERT INTO `transactions`(`transaction_code`, `transaction_type`, `encoder`, `prod_id`, `supp_id`, `warehouse_id`, `quantity`, `date`) 
				VALUES 
				('".$transaction_code."',
				'".$transaction_type."',
				'".$encoder."',
				'".$prod_id."',
				'".$supp_id."',
				'".$warehouse_id."',
				'".$transferQuantity."',
				'".$date."')";
		mysqli_query($conn, $sql);
		header("Location: prod_page.php");		
	}
}
?>