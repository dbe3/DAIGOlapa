<?php
session_start();
$connection = mysqli_connect("localhost", "root", "");
mysqli_select_db($connection,"daigolapa_accounts");
	$newUsername = $_POST['user_name'];
	$username = $_SESSION['username'];
	$newEmailaddress = $_POST['emailaddress'];
	$newFname = $_POST['fname'];
	$newLname = $_POST['lname'];

	
	$sql = "UPDATE users SET `user_name`='$newUsername', `emailaddress`='$newEmailaddress', `fname`='$fname', `lname`='$lname' WHERE user_name='$username'";
	
	mysqli_query($connection,$sql);
	
	$username = $_SESSION['newUsername'];
	header("Location: relogin.php");			
		
?>