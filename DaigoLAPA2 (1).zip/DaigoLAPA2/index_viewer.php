<html lang="en">
<head>

</head>
	<title>DaigoLAPA</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="css/homeStyle.css">
	<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
	
	<?php
		session_start();
		$username = $_SESSION['user_name'];
		if(!isset($username)){
			header("Location: login.php");
		}
	?>
	<body>
		
		<div class="header">
			<div class="greeting_msg">
				<a href="index_viewer.php"><font face="calibri" color="white">Welcome back, <?php echo $username ?></font></a>
			</div>
		
			
			<div class="btn-group dropleft">
				<button class="btn btn-secondary btn-lg dropdown-toggle" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
					<input type="image" class="icon" src="images/acc_icon.png" />
				</button>
					<div class="dropdown-menu">
							<a class="dropdown-item" href="account_viewer.php">Account</a>
							<a class="dropdown-item" href="help.php">Help</a>
							<a class="dropdown-item" href="about.php">About</a>
							<a class="dropdown-item" href="logout.php">Log Out</a>
					</div>
			</div>
		</div>
		
 <div id="London" class="tabcontent">
  <h1>DaigoLAPA</h1>
  <p>Inventory Management System</p>
</div>

<button class="tablink" onclick="openCity('London', this, '#079e80')" id="defaultOpen">DaigoLAPA</button>
<a href="prod_page_viewer.php"><button class="tablink" onclick="openCity('Paris', this, 'green')">Products</button></a>
<a href="supplier_page_viewer.php"><button class="tablink" onclick="openCity('Tokyo', this, 'blue')">Suppliers</button></a>
<button class="tablink" onclick="openCity('Oslo', this, 'orange')" disabled><font color="gray">Transactions</font></button> 
			
<div class="container">


<div id="viewProducts" class="modal fade" role="dialog">
  <div class="modal-dialog modal-lg">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
	  <h4 class="modal-title">All Products</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>
      <div class="modal-body">
        <table class="table table-dark" id="prod_table">
			<tr>
				<th scope="col"><center>Product Code</center></th>
				<th scope="col"><center>Product Name</center></th>
				<th scope="col"><center>Supplier</center></th>
				<th scope="col"><center>Product Price</center></th>
				<th scope="col"><center>Product Type</center></th>
				<th scope="col"><center>Product Quantity</center></th>
				<th scope="col"><center>Warehouse</center></th>
			</tr>
			
			<?php
			$conn = mysqli_connect("localhost", "root", "");
			mysqli_select_db($conn, "daigo_db");
			$query = "SELECT * FROM products INNER JOIN suppliers ON products.supp_id = suppliers.supp_id INNER JOIN warehouses on products.warehouse_id=warehouses.warehouse_id";
			$result = mysqli_query($conn, $query);
			while($rows = mysqli_fetch_assoc($result)){			
			?>
			<tr>
				<td><center><?php echo $rows['prod_code']; ?></center></td>
				<td><center><?php echo $rows['prod_name']; ?></center></td>
				<td><center><?php echo $rows['supp_name']; ?></center></td>
				<td><center><?php echo $rows['prod_price']; ?></center></td>
				<td><center><?php echo $rows['prod_type']; ?></center></td>
				<td><center><?php echo $rows['prod_quantity']; ?></center></td>
				<td><center><?php echo $rows['warehouse_name']; ?></center></td>
			</tr>
			<?php
			}
			?>
		</table>
			</div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>
<br>
<br><br><br>
<center><h2>Dashboard</h2></center>


<a href="#viewProducts" data-toggle="modal">
<button type="button" class="btn btn-info btn-lg btn-block">View All Products</button>
</a><br>

<?php
$query = "SELECT prod_expDate FROM products";
$result = mysqli_query($conn, $query);
$dateNow = date("Y-m-d");
?>
<a href="#viewExpiredProducts" data-toggle="modal">
<button type="button" class="btn btn-danger btn-lg btn-block">View Expired Products</button>
</a><br>
<a href="#viewDepletedProducts" data-toggle="modal">
<button type="button" class="btn btn-danger btn-lg btn-block">View Depleting Products</button>
</a>

<div id="viewDepletedProducts" class="modal fade" role="dialog">
  <div class="modal-dialog modal-lg">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
	  <h4 class="modal-title">Depleting Products</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>
      <div class="modal-body">	  	  
        <table class="table table-dark" id="prod_table">
			<tr>
				<th scope="col"><center>Product Code</center></th>
				<th scope="col"><center>Product Name</center></th>
				<th scope="col"><center>Product Type</center></th>
				<th scope="col"><center>Product Quantity</center></th>
				<th scope="col"><center>Warehouse</center></th>
				<th scope="col"><center>Supplier Info</center></th>
			</tr>
			
			<?php
			$query = "SELECT * FROM products INNER JOIN suppliers ON products.supp_id=suppliers.supp_id INNER JOIN warehouses ON products.warehouse_id=warehouses.warehouse_id";
			$result = mysqli_query($conn, $query);
			while($rows = mysqli_fetch_assoc($result)){
				if($rows['prod_status'] == "" && $rows['prod_quantity'] <= $rows['prod_critQuan']){
			?>
			<tr>
				<td><center><?php echo $rows['prod_code']; ?></center></td>
				<td><center><?php echo $rows['prod_name']; ?></center></td>
				<td><center><?php echo $rows['prod_type']; ?></center></td>
				<td><center><?php echo $rows['prod_quantity']; ?></center></td>
				<td><center><?php echo $rows['warehouse_name']; ?></center></td>
				<td><center>
				<a href="#view<?php echo $rows['prod_id'] ?>" data-toggle="modal">
				<button type="button" id="suppInfo" class="btn btn-success">View Supplier Info</button>
				</a>
				</center></td>
			</tr>
<div id="view<?php echo $rows['prod_id'] ?>" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
	  <h4 class="modal-title"><?php echo $rows['prod_name'] ?> Supplier Info</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>       
      </div>
      <div class="modal-body">

		<label>Supplier Name</label>
        <input type="text" class="form-control" placeholder="<?php echo $rows['supp_name']; ?>" readonly><br>
		<label>Supplier Location</label>
        <input type="text" class="form-control" placeholder="<?php echo $rows['supp_location']; ?>" readonly><br>
		<label>Supplier Contact Number</label>
        <input type="text" class="form-control" placeholder="<?php echo $rows['supp_conNum']; ?>" readonly><br>		
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>			
			<?php
				}
			}
			?>
		</table>	
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>


<div id="viewExpiredProducts" class="modal fade" role="dialog">
  <div class="modal-dialog modal-lg">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
	  <h4 class="modal-title">Expired Products</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        
      </div>
      <div class="modal-body">
        <table class="table table-dark" id="prod_table">
			<tr>
				<th scope="col"><center>Product Code</center></th>
				<th scope="col"><center>Product Name</center></th>
				<th scope="col"><center>Supplier</center></th>
				<th scope="col"><center>Product Type</center></th>
				<th scope="col"><center>Product Quantity</center></th>
				<th scope="col"><center>Warehouse</center></th>
			</tr>
			
			<?php
			$query = "SELECT * FROM products INNER JOIN suppliers ON products.supp_id=suppliers.supp_id INNER JOIN warehouses ON products.warehouse_id=warehouses.warehouse_id";
			$result = mysqli_query($conn, $query);
			$status = "Removed";
			while($rows = mysqli_fetch_assoc($result)){
			if($dateNow >= $rows['prod_expDate'] && $rows['prod_status'] != $status && $rows['prod_expDate'] != "0000-00-00"){
			?>
			<tr>
				<td><center><?php echo $rows['prod_code']; ?></center></td>
				<td><center><?php echo $rows['prod_name']; ?></center></td>
				<td><center><?php echo $rows['supp_name']; ?></center></td>
				<td><center><?php echo $rows['prod_type']; ?></center></td>
				<td><center><?php echo $rows['prod_quantity']; ?></center></td>
				<td><center><?php echo $rows['warehouse_name']; ?></center></td>
			</tr>
		
			<?php
				}
			}
			?>
		</table>		
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>	
</div>

				
					<script> 
						$('.nav nav-tabs card-header-tabs').on('click','li',function(){
						$('.nav nav-tabs card-header-tabs li-active').removeClass('active')
						});
					</script>	
			</nav>
		</div>	
		
		<script>
		function openCity(cityName, elmnt, color) {

  var i, tabcontent, tablinks;
  tabcontent = document.getElementsByClassName("tabcontent");
  for (i = 0; i < tabcontent.length; i++) {
    tabcontent[i].style.display = "none";
  }

  // Remove the background color of all tablinks/buttons
  tablinks = document.getElementsByClassName("tablink");
  for (i = 0; i < tablinks.length; i++) {
    tablinks[i].style.backgroundColor = "";
  }

  // Show the specific tab content
  document.getElementById(cityName).style.display = "block";

  // Add the specific color to the button used to open the tab content
  elmnt.style.backgroundColor = color;
}

// Get the element with id="defaultOpen" and click on it
document.getElementById("defaultOpen").click(); 
	</script>
	
	
	
</body>
</html>