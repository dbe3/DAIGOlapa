	<?php
session_start();
$connection = mysqli_connect("localhost", "root", "", "daigo_db");


$username = "";
$emailaddress = "";

if (isset($_POST['register'])){
	$username = $_POST['username'];
	$password = $_POST['password'];
	$emailaddress = $_POST['emailaddress'];
	$contact_number = $_POST['contact_number'];
	$fname = $_POST['fname'];
	$lname = $_POST['lname'];
	$privellege = $_POST['privellege'];
	
	$sql_checkUsername = "SELECT * FROM users WHERE user_name='$username'";
	$sql_checkEmail = "SELECT * FROM users WHERE emailaddress='$emailaddress'";
	$res_username = mysqli_query($connection, $sql_checkUsername);
	$res_email = mysqli_query($connection, $sql_checkEmail);
	
	if (mysqli_num_rows($res_username) > 0){
		$username_error = "Username already taken";
		
	}else if (mysqli_num_rows($res_email) > 0){
		$email_error = "Email is already in use"; 
	} else {
		$query = "INSERT INTO 
					`users`(`privillege`, `user_name`, `password`, `emailaddress`, `contact_number`, `fname`, `lname`) 
					VALUES 
					('".$privellege."',
					'".$username."',
					'".$password."',
					'".$emailaddress."',
					'".$contact_number."',
					'".$fname."',
					'".$lname."'
					)";	
		$results = mysqli_query($connection, $query);
		header("Location: register_success.php");
	}
}
?>