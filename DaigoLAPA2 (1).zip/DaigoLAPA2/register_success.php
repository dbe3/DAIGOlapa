<html lang="en">
<head>

</head>
	<title>DaigoLAPA</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<br>
		<center>
			<img height="500" width="500" src="images/logo_big.png">
			<h1>Register Successful</h1>
			<h1><a href="login.php"> Proceed to Login Page </a></h1>
		</center>
		
	<body>


</body>
</html>