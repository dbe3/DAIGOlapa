<html lang="en">
<head>

	<style>
		.boxed {
					width: 80%;
					height: 80%;
					background-color: #1abc9c;
					text-align: left;
					margin-left: auto;
					margin-right: auto;
					padding: 15px;
					margin-bottom:30px;
					margin-top: 20px;
				}
	</style>
	
</head>
	<title>DaigoLAPA</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="css/homeStyle.css">
	<link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.7.1/css/bootstrap-datepicker3.css" rel="stylesheet" id="bootstrap-css">
	<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
	<?php
		session_start();
		$username = $_SESSION['user_name'];
	?>
	<body>
		
		<div class="header">
			<div class="greeting_msg">
				<a href="index.php"><font face="calibri" color="white">Welcome back, <?php echo $username ?></font></a>
			</div>
			
		<div class="btn-group dropleft">
			<button class="btn btn-secondary btn-lg dropdown-toggle" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
				<input type="image" class="icon" src="images/acc_icon.png" />
			</button>
				<div class="dropdown-menu">
					    <a class="dropdown-item" href="account.php">Account</a>
						<a class="dropdown-item" href="help.php">Help</a>
						<a class="dropdown-item" href="about.php">About</a>
						<a class="dropdown-item" href="logout.php">Log Out</a>
				</div>
		</div>
		</div>
		<br>
  
 <div class="boxed" style="color: white">
 
	<center><h1>ACCOUNT INFORMATION</h1></center>
	

	<?php
	$connection = mysqli_connect("localhost", "root", "");
	mysqli_select_db($connection, "daigo_db");
	$query = "SELECT * FROM `users` WHERE user_name='$username'";
	$result = mysqli_query($connection, $query);
	$row = mysqli_fetch_assoc($result);
	?>
	<br><br><br><br><br><br>
	<table class="table table-dark" id="prod_table">
		<tr>
			<th>Username</th>
			<th>First Name</th>
			<th>Last Name</th>
			<th>Contact Number</th>
			<th>Email Address</th>			
			<th><center>Option</center></th>
		</tr>
		
		<tr>
			
			<td><center><?php echo $_SESSION['user_name']; ?></center></td>
			<td><center><?php echo $row['fname']; ?></center></td>
			<td><center><?php echo $row['lname']; ?></center></td>
			<td><center><?php echo $row['contact_number']; ?></center></td>
			<td><center><?php echo $row['emailaddress']; ?></center></td>
			<td>
			<center>
			<a href="#editInfo" data-toggle="modal">
			<button type="button" class="btn btn-success">Edit Information</button>
			</a>
			</center>
			</td>
		</tr>
	</table>
		

<div id="editInfo" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
		<h4 class="modal-title"><font color="black">Modal Header</font></h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>
      <div class="modal-body">
	  <form action="editUser.php" method="post">
        <label><font color="black">Username</font></label>
		<input type="text" class="form-control" name="user_name" value="<?php echo $_SESSION['user_name']; ?>" required></input><br>	
        <label><font color="black">Email Address</font></label>
		<input type="text" class="form-control" name="emailaddress" value="<?php echo $row['emailaddress']; ?>" required><?php echo $row['emailaddress']; ?></input><br>	
        <label><font color="black">First Name</font></label>
		<input type="text" class="form-control" name="fname" value="<?php echo $row['fname']; ?>" required><?php echo $row['fname']; ?></input><br>
        <label><font color="black">Last Name</font></label>
		<input type="text" class="form-control" name="lname" value="<?php echo $row['lname']; ?>" required><?php echo $row['lname']; ?></input><br>		
        <label><font color="black">Contact Number</font></label>
		<input type="number" class="form-control" name="contact_number" value="<?php echo $row['contact_number']; ?>" required><?php echo $row['contact_number']; ?></input><br>
		
		<button type="submit" class="btn btn-info">Save Changes</button>	
		
		</form>				
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>
							
<script type="text/javascript">
function showNew2(name){
  if(name=='editNewSupp')document.getElementById('editNewSupp').innerHTML=
  '<input type="text" class="form-control" name="supp_name" id="inputPassword4" placeholder="Supplier Name" required>';
  else document.getElementById('newSupp').innerHTML='';
}
</script>



<script>

 $('#prod_table').SetEditable({ $edit: $('#edit')});
</script>
		

		
		
		<script>
		function openCity(cityName, elmnt, color) {

  var i, tabcontent, tablinks;
  tabcontent = document.getElementsByClassName("tabcontent");
  for (i = 0; i < tabcontent.length; i++) {
    tabcontent[i].style.display = "none";
  }

  // Remove the background color of all tablinks/buttons
  tablinks = document.getElementsByClassName("tablink");
  for (i = 0; i < tablinks.length; i++) {
    tablinks[i].style.backgroundColor = "";
  }

  // Show the specific tab content
  document.getElementById(cityName).style.display = "block";

  // Add the specific color to the button used to open the tab content
  elmnt.style.backgroundColor = color;
}

// Get the element with id="defaultOpen" and click on it
document.getElementById("defaultOpen").click(); 
	</script>

<script>
function myFunction() {
  // Declare variables 
  var input, filter, table, tr, td, i, txtValue;
  input = document.getElementById("myInput");
  filter = input.value.toUpperCase();
  table = document.getElementById("prod_table");
  tr = table.getElementsByTagName("tr");

  // Loop through all table rows, and hide those who don't match the search query
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[0];
    if (td) {
      txtValue = td.textContent || td.innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    } 
  }
}
</script>	



</body>
</html>