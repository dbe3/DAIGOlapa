<?php
session_start();
$connection = mysqli_connect("localhost", "root", "");
mysqli_select_db($connection, "daigo_db");
$encoder = $_POST['username'];
$prod_code = $_POST['prod_code'];
$prod_name = $_POST['prod_name'];
$prod_price = $_POST['prod_price'];
$prod_type = $_POST['prod_type'];
$prod_quantity = $_POST['prod_quantity'];
$prod_critQuan = $_POST['prod_critQuan'];
$prod_expDate = $_POST['prod_expDate'];
$supp_id = $_POST['supp_id'];
$warehouse_id = $_POST['warehouse_id'];
$transaction_code = "PD-".$_POST['transaction_code'];
$transaction_type = "Product Delivery";
$sql_prodCode = "SELECT * FROM products WHERE prod_code='$prod_code'";
$date = date("Y/m/d");
$prod_id = "qaa";
$res_prodCode = mysqli_query($connection, $sql_prodCode);

	$connection = mysqli_connect("localhost", "root", "");
	mysqli_select_db($connection, "daigo_db");
	$supp_name = $_POST['supp_name'];
	$supp_location = $_POST['supp_location'];
	$supp_conNum = $_POST['supp_conNum'];
	$sql_checkSuppName = "SELECT * FROM suppliers WHERE supp_name='$supp_name'";
	$res_suppName = mysqli_query($connection, $sql_checkSuppName);
	
	if (mysqli_num_rows($res_suppName) > 0){
	mysqli_close($connection);
	}else{
	$sql = "INSERT INTO `suppliers`(`supp_name`, `supp_location`, `supp_conNum`) 
			VALUES ('".$supp_name."','".$supp_location."','".$supp_conNum."')";	
			mysqli_query($connection,$sql);	
			mysqli_close($connection);			
	}
	
	$connection = mysqli_connect("localhost", "root", "");
	mysqli_select_db($connection, "daigo_db");
	$warehouse_location = $_POST['warehouse_location'];
	$warehouse_conNum = $_POST['warehouse_conNum'];
	$warehouse_name = $_POST['warehouse_name'];
	$sql_checkWarehouseName = "SELECT * FROM warehouses WHERE warehouse_name='$warehouse_name'";
	$res_warehouseName = mysqli_query($connection, $sql_checkWarehouseName);
	
	if (mysqli_num_rows($res_warehouseName) > 0){
		mysqli_close($connection);
		header("Location: prod_page.php");
	}else{
		$sql = "INSERT INTO `warehouses`(`warehouse_name`, `warehouse_location`, `warehouse_conNum`)
			VALUES ('".$warehouse_name."','".$warehouse_location."','".$warehouse_conNum."')";
			mysqli_query($connection,$sql);
			mysqli_close($connection);		
			header("Location: prod_page.php");
	}
	
if (mysqli_num_rows($res_prodCode) > 0){
	header("Location: transaction_page.php");
}else{
$sql = "INSERT INTO `products`(`prod_code`, `prod_name`, `prod_price`, `prod_type`, `prod_quantity`, `prod_critQuan`, `prod_expDate`, `supp_id`, `warehouse_id`) 
		VALUES 
		(
		'".$prod_code ."',
		'".$prod_name."',
		'".$prod_price."',
		'".$prod_type."',
		'".$prod_quantity."',
		'".$prod_critQuan."',
		'".$prod_expDate."',
		'".$supp_id."',
		'".$warehouse_id."')";	
		
		mysqli_query($connection,$sql);
		mysqli_close($connection);		
}



?>